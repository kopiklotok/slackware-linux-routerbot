export PATH=$HOME/.heroku/php/bin:$PATH:$HOME/vendor/bin
